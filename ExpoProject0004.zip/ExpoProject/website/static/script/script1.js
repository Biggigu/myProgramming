document.addEventListener("DOMContentLoaded", function () {
    let timer;
    let startTime;
    let elapsedTime = 0;
    let running = false;

    const timerDisplay = document.getElementById("timer-display");
    const startButton = document.getElementById("start-button");

    function formatTime(ms) {
        const totalSeconds = Math.floor(ms / 1000);
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
    }

    function updateTimer() {
        const currentTime = Date.now();
        elapsedTime = currentTime - startTime;
        timerDisplay.textContent = formatTime(elapsedTime);
    }

    startButton.addEventListener("click", function () {
        if (!running) {
            running = true;
            startTime = Date.now() - elapsedTime;  // Keeps correct time on restart
            updateTimer();  // Update immediately instead of waiting 1 second

            clearInterval(timer);  // Make sure no duplicate intervals exist
            timer = setInterval(updateTimer, 1000);  // Start interval properly
        }
    });
});
