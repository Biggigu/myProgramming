document.addEventListener("DOMContentLoaded", function () {
    let countdown;
    let timeLeft = 300; // Example: 5 minutes (in seconds)
    let running = false;

    const timerDisplay = document.getElementById("timer-display");
    const startButton = document.getElementById("start-button");
    const stopButton = document.getElementById("stop-button");

    function formatTime(seconds) {
        let minutes = Math.floor(seconds / 60);
        let secs = seconds % 60;
        return `${minutes}:${secs < 10 ? "0" : ""}${secs}`;
    }

    function updateTimer() {
        timerDisplay.textContent = formatTime(timeLeft);
    }

    startButton.addEventListener("click", function () {
        if (!running) {
            running = true;
            updateTimer(); // Ensure UI updates immediately
            countdown = setInterval(function () {
                if (timeLeft > 0) {
                    timeLeft--; // Decrease countdown
                    updateTimer();
                } else {
                    clearInterval(countdown);
                    alert("Time is up!");
                    running = false;
                }
            }, 1000); // Runs every second
        }
    });

    stopButton.addEventListener("click", function () {
        if (running) {
            running = false;
            clearInterval(countdown);
            alert("Timer stopped at: " + formatTime(timeLeft));
        }
    });

    updateTimer(); // Initialize display at page load
});
