import os
import base64
import sqlite3
from flask import Flask, render_template, request, jsonify, redirect, url_for
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from email.mime.text import MIMEText

app = Flask(__name__)

# Path to your credentials JSON file
CREDENTIALS_FILE = "credentials.json"

# Gmail API Scopes
SCOPES = ["https://www.googleapis.com/auth/gmail.send"]

# Database setup
def init_db():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS participants (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            surname TEXT,
            email TEXT,
            contact TEXT,
            escape_time INTEGER
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# Function to authenticate and get Gmail API service
def get_gmail_service():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
        creds = flow.run_local_server(port=5000)
        with open("token.json", "w") as token:
            token.write(creds.to_json())
    return build("gmail", "v1", credentials=creds)

# Function to send an email via Gmail API
def send_email(to_email, name, escape_time):
    try:
        service = get_gmail_service()
        formatted_time = f"{(escape_time // 1000) // 60}:{(escape_time // 1000) % 60:02d}"
        
        subject = "EXPO Escape Room - Your Results"
        body = f"Hello {name}, Congratulations! You completed the escape room in {formatted_time}. Check the leaderboard to see where you stand! Best, EXPO Team"

        print(f"📩 Preparing to send email to {to_email}")

        message = MIMEText(body)
        message["to"] = to_email
        message["subject"] = subject

        raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
        email_data = {"raw": raw}

        service.users().messages().send(userId="me", body=email_data).execute()
        print(f"✅ Email sent successfully to {to_email}")
    except Exception as e:
        print(f"❌ Email sending failed: {e}")

# Home route
@app.route("/")
def home():
    return render_template("index.html")

# User registration
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "Anonymous")
        surname = request.form.get("surname", "")
        email = request.form.get("email", "")
        contact = request.form.get("contact", "")

        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()
        cursor.execute("INSERT INTO participants (name, surname, email, contact) VALUES (?, ?, ?, ?)",
                       (name, surname, email, contact))
        conn.commit()
        user_id = cursor.lastrowid
        conn.close()

        return redirect(url_for("timer", user_id=user_id))
    return render_template("register.html")

# Timer page
@app.route("/timer/<int:user_id>")
def timer(user_id):
    return render_template("timer.html", user_id=user_id)

# Submit score and send email
@app.route("/submit_score", methods=["POST"])
def submit_score():
    data = request.json
    user_id = data.get("player_id")
    escape_time = data.get("escape_time")

    print(f"Received score submission - Player ID: {user_id}, Escape Time: {escape_time}")  # Debugging log

    if not user_id or escape_time is None:
        return jsonify({"success": False, "message": "Invalid data"}), 400

    try:
        conn = sqlite3.connect("database.db")
        cursor = conn.cursor()
        cursor.execute("UPDATE participants SET escape_time = ? WHERE id = ?", (escape_time, user_id))
        cursor.execute("SELECT name, email FROM participants WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        conn.commit()
        conn.close()

        if user and user[1]:  # If the user has provided an email
            print(f"📧 Sending email to {user[1]} for user {user[0]}")
            send_email(user[1], user[0], escape_time)

        return jsonify({"success": True})
    except Exception as e:
        print(f"❌ Error submitting score: {e}")
        return jsonify({"success": False, "message": str(e)}), 500

# Result page
@app.route("/result")
def result():
    player_id = request.args.get("player_id")
    time_in_ms = request.args.get("time", "0")

    try:
        time_in_ms = int(time_in_ms)
    except ValueError:
        return "Invalid time format", 400

    minutes = (time_in_ms // 1000) // 60
    seconds = (time_in_ms // 1000) % 60
    formatted_time = f"{minutes}:{seconds:02d}"

    return render_template("result.html", player_id=player_id, time=formatted_time)

# Leaderboard API
@app.route("/get_leaderboard")
def get_leaderboard():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("SELECT name, escape_time FROM participants WHERE escape_time IS NOT NULL ORDER BY escape_time ASC LIMIT 10")
    leaderboard = [{"name": row[0], "escape_time": f"{(row[1] // 1000) // 60}:{(row[1] // 1000) % 60:02d}"} for row in cursor.fetchall()]
    conn.close()
    return jsonify(leaderboard)

# Leaderboard page
@app.route("/leaderboard")
def leaderboard():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("SELECT name, escape_time FROM participants WHERE escape_time IS NOT NULL ORDER BY escape_time ASC LIMIT 10")
    leaderboard = [{"name": row[0], "escape_time": f"{(row[1] // 1000) // 60}:{(row[1] // 1000) % 60:02d}"} for row in cursor.fetchall()]
    conn.close()
    return render_template("leaderboard.html", leaderboard=leaderboard)

# Test email route
@app.route("/test_email")
def test_email():
    send_email("expo25.mhse@gmail.com", "Test User", 12345)
    return "Email Sent"

if __name__ == "__main__":
    app.run(debug=True)