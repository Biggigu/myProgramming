from flask import send_file, Blueprint, render_template,redirect
import pandas as pd
from io import BytesIO
import sqlite3
import databaseHandler as dbHandle

exportDB = Blueprint('export', __name__)

@exportDB.route('/export', methods=['GET'])
def exportData():
    conn = sqlite3.connect('data.db')  # or use MySQL connector
    df = pd.read_sql_query("SELECT * FROM players", conn)  # adjust your table name
    conn.close()

    # Convert to Excel in memory
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Data')
    output.seek(0)

    dbHandle.databaseClear()
    
    #redirect("index.html")  
    # Send as downloadable file
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name='Participants_Score.xlsx'
    )