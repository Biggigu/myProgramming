import os
import base64
import sqlite3
from flask import Flask, render_template, request, jsonify, redirect, url_for
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from email.mime.text import MIMEText

app = Flask(__name__)

# Environment variables for security
CREDENTIALS_FILE = os.getenv("GOOGLE_CREDENTIALS", "credentials.json")

# Gmail API Scopes
SCOPES = ["https://www.googleapis.com/auth/gmail.send"]

# Database setup with timestamps
def init_db():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS participants (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            surname TEXT,
            email TEXT,
            contact TEXT,
            escape_time INTEGER,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# Function to authenticate and get Gmail API service with refresh support
def get_gmail_service():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
        creds = flow.run_local_server(port=5000)
        with open("token.json", "w") as token:
            token.write(creds.to_json())
    return build("gmail", "v1", credentials=creds)

# Function to send an email via Gmail API with error handling
def send_email(to_email, name, escape_time):
    try:
        service = get_gmail_service()
        formatted_time = f"{(escape_time // 1000) // 60}:{(escape_time // 1000) % 60:02d}"
        
        subject = "EXPO Escape Room - Your Results"
        body = f"Hello {name}, Congratulations! You completed the escape room in {formatted_time}. Check the leaderboard to see where you stand! Best, EXPO Team"

        message = MIMEText(body)
        message["to"] = to_email
        message["subject"] = subject
        encoded_message = {"raw": base64.urlsafe_b64encode(message.as_bytes()).decode()}

        service.users().messages().send(userId="me", body=encoded_message).execute()
        print(f"✅ Email sent to {to_email}")
        return True
    except Exception as e:
        print(f"❌ Email sending failed: {e}")
        return False

# Result Route Fix
@app.route('/result')
def result():
    player_id = request.args.get("player_id")
    escape_time = request.args.get("time")

    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM participants WHERE id=?", (player_id,))
    result = cursor.fetchone()
    conn.close()

    name = result[0] if result else "Participant"
    formatted_time = f"{(int(escape_time) // 1000) // 60}:{(int(escape_time) // 1000) % 60:02d}"

    return render_template("result.html", name=name, formatted_time=formatted_time)

if __name__ == "__main__":
    app.run(debug=True)
