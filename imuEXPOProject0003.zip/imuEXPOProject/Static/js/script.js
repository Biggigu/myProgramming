document.addEventListener("DOMContentLoaded", function () {
    let timer;
    let startTime;
    let elapsedTime = 0;
    let running = false;

    const timerDisplay = document.getElementById("timer-display");
    const startButton = document.getElementById("start-button");
    const stopButton = document.getElementById("stop-button");
    const playerID = document.getElementById("player-id").value; // Read the ID properly

    function formatTime(ms) {
        const totalSeconds = Math.floor(ms / 1000);
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
    }

    function updateTimer() {
        const currentTime = Date.now();
        elapsedTime = currentTime - startTime;
        timerDisplay.textContent = formatTime(elapsedTime);
    }

    startButton.addEventListener("click", function () {
        if (!running) {
            running = true;
            startTime = Date.now() - elapsedTime;
            timer = setInterval(updateTimer, 1000);
        }
    });

    stopButton.addEventListener("click", function () {
        if (running) {
            running = false;
            clearInterval(timer);
            sendScore();
        }
    });

    function sendScore() {
        if (!playerID || playerID === "undefined") {
            alert("Error: No player ID found!");
            return;
        }

        fetch("/submit_score", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                player_id: playerID,
                escape_time: elapsedTime // Send milliseconds, NOT MM:SS
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = `/result?player_id=${playerID}&time=${elapsedTime}`;
            } else {
                alert("Error submitting score.");
            }
        })
        .catch(error => console.error("Error:", error));
    }
});
