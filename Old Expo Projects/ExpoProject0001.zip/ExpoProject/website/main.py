from flask import Flask,render_template
import databaseHandler

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/leaderboard")
def leaderboard():
    return render_template("leaderboard.html")

@app.route("/register")
def register():
    return render_template("register.html")

@app.route("/result")
def result():
    return render_template("result.html")

@app.route("/timer")
def timer():
    return render_template("timer.html")




if __name__ == '__main__':
    #init_db()
    app.run(debug=True)

