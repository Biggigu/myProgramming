import smtplib, ssl

def sendEmail(receiver, message):
    host = "smtp.gmail.com"
    port = 465

    username = "expo25.mhse@gmail.com"
    password = "xjkx vohf zdcz zwad"

    participant=receiver

    context = ssl.create_default_context()

    with smtplib.SMTP_SSL(host,port,context=context) as server:
        server.login(username, password)
        server.sendmail(username,participant,message)