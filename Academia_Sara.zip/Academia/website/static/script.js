let countdown;
let timeLeft = 0; 
let running = false;

const formatTime = (seconds) => {
    let minutes = Math.floor(seconds / 60);
    let secs = seconds % 60;
    return `${minutes}:${secs < 10 ? "0" : ""}${secs}`;
};

function updateTimer() {
    const timerDisplay = document.getElementById("timer-display");
    timerDisplay.value = formatTime(timeLeft);
    timerDisplay.setAttribute("data-time", timeLeft);
}

function startTimer(){
    if (!running) {
        running = true;
        updateTimer();
        countdown = setInterval(() => {
            if (timeLeft >= 0) {
                timeLeft++;
                updateTimer();
            } else {
                clearInterval(countdown);
                window.location = "result";
                running = false;
            }
        }, 1000);
    }
}

// Expose to global scope so HTML can call it
window.startTimer = startTimer;

let timerDis = window.open('', 'TimerWindow');


document.addEventListener("DOMContentLoaded", function () {
    const startButton = document.getElementById("start-button");
    const stopButton = document.getElementById("stop-button");
    const timerDisplay = document.getElementById("timer-display");

    if (startButton) {
        startButton.addEventListener("click", function () {
            let leaderBoard = window.open('', 'LeaderBoardWindow');

            leaderBoard.postMessage("Timer","*")
            startTimer();
        });
    }

    if (stopButton) {
        stopButton.addEventListener("click", function () {
            if (running) {
                running = false;
                clearInterval(countdown);
                timerDisplay.value = timeLeft;
                stopButton.closest("form").submit();
            }
        });
    }

    window.addEventListener("message", function(event) {
        if (event.data === "Timer") {
            window.location.href = "/timerDisplay";
        }
    });
});